#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "QDebug"
MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    ui->remove->setCheckable(false);
    ui->remove->setChecked(false);
    connect(ui->remove,SIGNAL(clicked(bool)),ui->Logging,SLOT(setEnabled(bool)));
    connect(ui->remove,SIGNAL(clicked(bool)),ui->PF1,SLOT(setEnabled(bool)));
    connect(ui->remove,SIGNAL(clicked(bool)),ui->pushButton_25,SLOT(setEnabled(bool)));

    //ui->IG->setText("bla bla");
    //connect(ui->Button19,SIGNAL(clicked(bool)),ui->Mail,SLOT(setEnabled(bool)));
}

void MainWindow::paintEvent(QPaintEvent *event)
{
    QPainter Painter(this);
    QPen Linepen(Qt::gray);
    Linepen.setWidth(2);
    Painter.setPen(Linepen);
    QPoint P1;
    P1.setX(70);
    P1.setY(312);

    QPoint P21;
    P21.setX(330);
    P21.setY(302);
    QPoint P22;
    P22.setX(330);
    P22.setY(322);
    QPoint P23;
    P23.setX(340);
    P23.setY(312);
    Painter.drawLine(P21,P22);
    Painter.drawLine(P21,P23);
    Painter.drawLine(P22,P23);

    QPoint P24;
    P24.setX(380);
    P24.setY(302);
    QPoint P25;
    P25.setX(380);
    P25.setY(322);
    QPoint P26;
    P26.setX(390);
    P26.setY(312);
    Painter.drawLine(P24,P25);
    Painter.drawLine(P24,P26);
    Painter.drawLine(P25,P26);

    QPoint P51;
    P51.setX(350);
    P51.setY(332);
    QPoint P52;
    P52.setX(370);
    P52.setY(332);
    QPoint P53;
    P53.setX(360);
    P53.setY(342);
    Painter.drawLine(P51,P52);
    Painter.drawLine(P52,P53);
    Painter.drawLine(P53,P51);

    QPoint P27;
    P27.setX(330);
    P27.setY(702);
    QPoint P28;
    P28.setX(330);
    P28.setY(722);
    QPoint P29;
    P29.setX(320);
    P29.setY(712);
    Painter.drawLine(P27,P28);
    Painter.drawLine(P28,P29);
    Painter.drawLine(P29,P27);


    QPoint P2;// re nhanh
    P2.setX(360);
    P2.setY(312);
    Painter.drawLine(P1,P2);

    QPoint P3;//re nhanh
    P3.setX(550);
    P3.setY(312);
    Painter.drawLine(P2,P3);

    QPoint P4;
    P4.setX(730);
    P4.setY(312);
    Painter.drawLine(P3,P4);

    QPoint P5;
    P5.setX(550);
    P5.setY(242);
    Painter.drawLine(P3,P5);

    QPoint P6;
    P6.setX(730);
    P6.setY(242);
    Painter.drawLine(P5,P6);

    QPoint P7;
    P7.setX(550);
    P7.setY(172);
    Painter.drawLine(P5,P7);

    QPoint P8;
    P8.setX(730);
    P8.setY(172);
    Painter.drawLine(P7,P8);

    QPoint P9;
    P9.setX(550);
    P9.setY(102);
    Painter.drawLine(P7,P9);

    QPoint P10;
    P10.setX(730);
    P10.setY(102);
    Painter.drawLine(P9,P10);

    QPoint P31;
    P31.setX(550);
    P31.setY(382);
    Painter.drawLine(P3,P31);

    QPoint P32;
    P32.setX(730);
    P32.setY(382);
    Painter.drawLine(P31,P32);

    QPoint P33;
    P33.setX(550);
    P33.setY(452);
    Painter.drawLine(P31,P33);

    QPoint P34;
    P34.setX(730);
    P34.setY(452);
    Painter.drawLine(P33,P34);

    QPoint P35;
    P35.setX(550);
    P35.setY(522);
    Painter.drawLine(P33,P35);

    QPoint P36;
    P36.setX(730);
    P36.setY(522);
    Painter.drawLine(P35,P36);

    QPoint P11;
    P11.setX(360);
    P11.setY(712);
    Painter.drawLine(P2,P11);

    QPoint P12;
    P12.setX(70);
    P12.setY(712);
    Painter.drawLine(P11,P12);
    Painter.drawLine(P12,P1);

}

MainWindow::~MainWindow()
{
    delete ui;
}
